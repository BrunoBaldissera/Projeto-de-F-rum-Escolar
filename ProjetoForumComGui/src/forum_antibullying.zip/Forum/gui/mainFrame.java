package Forum.gui;

import forumSistema.*;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.DropMode;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JEditorPane;

public class mainFrame extends JFrame {

	private JPanel contentPane;
	public Sistema s;
	public Usuario u;
	public JLabel currentCounter;
	public int npag;
	public int pagAtual;
	public ArrayList<JButton> buttons;
	public ArrayList<JLabel> labels;

	public ArrayList<Mensagem> arrMensagens;
	
	public void atualizaPosts() {
		npag = (int) Math.ceil(s.postagens.size() / 7.0);
		currentCounter.setText("PAGINA ATUAL:  " + pagAtual + " DE " + npag);
		
		ArrayList<Mensagem> m = s.getPostagens();
		
		int k = 7;
		for(Mensagem atual : m ) {
			int i = m.indexOf(atual);
			
			if(i >= 7 * (pagAtual - 1) && i < 7 * pagAtual) {
				
				k = i%7;
				labels.get(k).setText(atual.getTitulo());
				labels.get(k).setVisible(true);
				buttons.get(k).setVisible(true);
				buttons.get(k).setEnabled(true);
		
				arrMensagens.set(k, atual);
			}
		}
		
		k++;
		
		while(k < 7) {
			labels.get(k).setVisible(false);
			buttons.get(k).setVisible(false);
			buttons.get(k).setEnabled(false);
			k++;
		}
		
	}
	
	public mainFrame(Sistema s, Usuario u) {
		
		buttons = new ArrayList<JButton>();
		labels = new ArrayList<JLabel>();
		arrMensagens = new ArrayList<Mensagem>();
		mainFrame f = this;
		
		setResizable(false);
		setForeground(new Color(102, 102, 204));
		this.s = s;
		this.u = u;
		npag = (int) Math.ceil(s.postagens.size() / 7.0);
		pagAtual = 1;
		
		setMinimumSize(new Dimension(800, 800));
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(102, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JLabel greetLabel = new JLabel("Bom dia " + u.getNome() + "! Esse eh o seu feed de postagens:");
		sl_contentPane.putConstraint(SpringLayout.NORTH, greetLabel, 10, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, greetLabel, 111, SpringLayout.WEST, contentPane);
		greetLabel.setFont(new Font("Dialog", Font.BOLD, 16));
		contentPane.add(greetLabel);
		
		for (int i = 0; i < 7; i++) {
			arrMensagens.add(null);
		}
		
		JLabel lblPost = new JLabel("post1");
		lblPost.setVisible(false);
		lblPost.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost, 268, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost, -550, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost);
		labels.add(lblPost);
		
		
		JLabel lblPost_1 = new JLabel("post2");
		lblPost_1.setVisible(false);
		lblPost_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPost_1, 52, SpringLayout.SOUTH, lblPost);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost_1, 0, SpringLayout.WEST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost_1, -480, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost_1);
		labels.add(lblPost_1);
		
		JLabel lblPost_2 = new JLabel("post7");
		lblPost_2.setVisible(false);
		lblPost_2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPost_2, 58, SpringLayout.SOUTH, lblPost_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost_2, 0, SpringLayout.WEST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost_2, -404, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost_2);
		labels.add(lblPost_2);
		
		JLabel lblPost_3 = new JLabel("post");
		lblPost_3.setVisible(false);
		lblPost_3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPost_3, 65, SpringLayout.SOUTH, lblPost_2);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost_3, 0, SpringLayout.WEST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost_3, -321, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost_3);
		labels.add(lblPost_3);
		
		JLabel lblPost_4 = new JLabel("post");
		lblPost_4.setVisible(false);
		lblPost_4.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPost_4, 58, SpringLayout.SOUTH, lblPost_3);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost_4, 0, SpringLayout.WEST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost_4, -245, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost_4);
		labels.add(lblPost_4);
		
		JLabel lblPost_5 = new JLabel("post");
		lblPost_5.setVisible(false);
		lblPost_5.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPost_5, 35, SpringLayout.SOUTH, lblPost_4);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost_5, 0, SpringLayout.WEST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost_5, -192, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost_5);
		labels.add(lblPost_5);
		
		JLabel lblPost_6 = new JLabel("post");
		lblPost_6.setVisible(false);
		lblPost_6.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblPost_6, 45, SpringLayout.SOUTH, lblPost_5);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblPost_6, 0, SpringLayout.WEST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblPost_6, -129, SpringLayout.SOUTH, contentPane);
		contentPane.add(lblPost_6);
		labels.add(lblPost_6);
		
		JButton button = new JButton("Acessar");
		button.setEnabled(false);
		button.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, button, -3, SpringLayout.NORTH, lblPost);
		sl_contentPane.putConstraint(SpringLayout.WEST, button, 114, SpringLayout.EAST, lblPost);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, button, -540, SpringLayout.SOUTH, contentPane);
		contentPane.add(button);
		buttons.add(button);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(0), u, f);
				frame.setVisible(true);
			}
		});
		
		
		JButton button_1 = new JButton("Acessar");
		button_1.setEnabled(false);
		button_1.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, button_1, -3, SpringLayout.NORTH, lblPost_1);
		sl_contentPane.putConstraint(SpringLayout.WEST, button_1, 0, SpringLayout.WEST, button);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, button_1, -470, SpringLayout.SOUTH, contentPane);
		contentPane.add(button_1);
		buttons.add(button_1);
		button_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(1), u, f);
				frame.setVisible(true);
			}
		});
		
		JButton button_2 = new JButton("Acessar");
		button_2.setEnabled(false);
		button_2.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.WEST, button_2, 0, SpringLayout.WEST, button);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, button_2, 0, SpringLayout.SOUTH, lblPost_2);
		contentPane.add(button_2);
		buttons.add(button_2);
		button_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(2), u, f);
				frame.setVisible(true);
			}
		});
		
		JButton button_3 = new JButton("Acessar");
		button_3.setEnabled(false);
		button_3.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, button_3, -2, SpringLayout.NORTH, lblPost_3);
		sl_contentPane.putConstraint(SpringLayout.WEST, button_3, 125, SpringLayout.EAST, lblPost_3);
		sl_contentPane.putConstraint(SpringLayout.EAST, button_3, 0, SpringLayout.EAST, button);
		contentPane.add(button_3);
		buttons.add(button_3);
		button_3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(3), u, f);
				frame.setVisible(true);
			}
		});
		
		JButton button_4 = new JButton("Acessar");
		button_4.setEnabled(false);
		button_4.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.WEST, button_4, 0, SpringLayout.WEST, button);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, button_4, 0, SpringLayout.SOUTH, lblPost_4);
		contentPane.add(button_4);
		buttons.add(button_4);
		button_4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(4), u, f);
				frame.setVisible(true);
			}
		});
		
		JButton button_5 = new JButton("Acessar");
		button_5.setEnabled(false);
		button_5.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.NORTH, button_5, -2, SpringLayout.NORTH, lblPost_5);
		sl_contentPane.putConstraint(SpringLayout.WEST, button_5, 125, SpringLayout.EAST, lblPost_5);
		sl_contentPane.putConstraint(SpringLayout.EAST, button_5, 0, SpringLayout.EAST, button);
		contentPane.add(button_5);
		buttons.add(button_5);
		button_5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(5), u, f);
				frame.setVisible(true);
			}
		});
		
		JButton button_6 = new JButton("Acessar");
		button_6.setEnabled(false);
		button_6.setVisible(false);
		sl_contentPane.putConstraint(SpringLayout.WEST, button_6, 0, SpringLayout.WEST, button);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, button_6, 0, SpringLayout.SOUTH, lblPost_6);
		contentPane.add(button_6);
		buttons.add(button_6);
		button_6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameView frame = new frameView(s, arrMensagens.get(6), u, f);
				frame.setVisible(true);
			}
		});
		
		
		
		
		
		
		JButton previous = new JButton("<");
		previous.setHorizontalAlignment(SwingConstants.LEFT);
		previous.setHorizontalTextPosition(SwingConstants.CENTER);
		sl_contentPane.putConstraint(SpringLayout.EAST, previous, -345, SpringLayout.EAST, button);
		previous.setVisible(false);
		previous.setEnabled(false);
		sl_contentPane.putConstraint(SpringLayout.WEST, previous, 77, SpringLayout.WEST, contentPane);
		contentPane.add(previous);
		
		
		
		currentCounter = new JLabel(" ");
		atualizaPosts();
		sl_contentPane.putConstraint(SpringLayout.WEST, currentCounter, 246, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, currentCounter, -70, SpringLayout.NORTH, button);
		contentPane.add(currentCounter);
		
		
		
		JButton next = new JButton(">");
		next.setEnabled(npag > 1);
		next.setVisible(npag > 1);
		sl_contentPane.putConstraint(SpringLayout.NORTH, previous, -5, SpringLayout.NORTH, next);
		sl_contentPane.putConstraint(SpringLayout.NORTH, next, 343, SpringLayout.SOUTH, greetLabel);
		sl_contentPane.putConstraint(SpringLayout.EAST, next, -66, SpringLayout.EAST, contentPane);
		contentPane.add(next);
		
		
		previous.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				pagAtual--;
				previous.setVisible(pagAtual > 1);
				previous.setEnabled(pagAtual > 1);
				next.setVisible(pagAtual < npag);
				next.setEnabled(pagAtual < npag);
				atualizaPosts();
			}
		});
		
		next.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				pagAtual++;
				previous.setVisible(pagAtual > 1);
				previous.setEnabled(pagAtual > 1);
				next.setVisible(pagAtual < npag);
				next.setEnabled(pagAtual < npag);
				atualizaPosts();
			}
		});
		
		
		JLabel forcaguerreirx = new JLabel("LEMBRE-SE QUE VOCE NAO ESTA SOZINHO!");
		sl_contentPane.putConstraint(SpringLayout.NORTH, forcaguerreirx, 49, SpringLayout.SOUTH, lblPost_6);
		sl_contentPane.putConstraint(SpringLayout.WEST, forcaguerreirx, 0, SpringLayout.WEST, currentCounter);
		contentPane.add(forcaguerreirx);
		
		JButton listadePendentes = new JButton("Lista de Pendentes");
		listadePendentes.setVisible(u instanceof UsuarioModerador);
		listadePendentes.setEnabled(u instanceof UsuarioModerador);
		sl_contentPane.putConstraint(SpringLayout.NORTH, listadePendentes, 109, SpringLayout.SOUTH, greetLabel);
		sl_contentPane.putConstraint(SpringLayout.EAST, listadePendentes, 0, SpringLayout.EAST, next);
		contentPane.add(listadePendentes);
		
		
		listadePendentes.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(!s.getPendentes().isEmpty()) {
					framePendentes frame = new framePendentes(s, s.getPendentes().get(0));
					frame.setVisible(true);
				}
			}
		});
		
		
		JButton postar = new JButton("Criar Postagem");
		sl_contentPane.putConstraint(SpringLayout.NORTH, postar, 0, SpringLayout.NORTH, listadePendentes);
		sl_contentPane.putConstraint(SpringLayout.WEST, postar, 65, SpringLayout.WEST, contentPane);
		contentPane.add(postar);
		
		JButton btnSair = new JButton("SAIR");
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnSair, -52, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnSair, -31, SpringLayout.EAST, contentPane);
		contentPane.add(btnSair);
		btnSair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				frameLogin frame = new frameLogin(s);
				frame.setVisible(true);
				dispose();
			}
		});
		
		
		
		
		postar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				framePostar frame = new framePostar(s, u, f);
				frame.setVisible(true);
			}
		});
		
	}

}
